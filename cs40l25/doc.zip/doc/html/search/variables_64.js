var searchData=
[
  ['data',['data',['../structcs40l25__dsp__status__t.html#ace8225f4598d39984dcf6e9cc02a2649',1,'cs40l25_dsp_status_t']]],
  ['devid',['devid',['../structcs40l25__t.html#ade9fdb65c8601ec85914d910e28720b3',1,'cs40l25_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]]
];
