var searchData=
[
  ['peak_5famplitude_834',['peak_amplitude',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gaee64b2011e609e854ac070b22155be57',1,'cs40l25_dsp_config_controls_t']]],
  ['playback_5fend_5fsuspend_835',['playback_end_suspend',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga74e8f51b36ac14e777a2dd318d7b841d',1,'cs40l25_event_control_t::playback_end_suspend()'],['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga52d2e81c1933ef3524a56e166e68a207',1,'cs40l25_event_control_t::@0::@2::playback_end_suspend()']]],
  ['playback_5fresume_836',['playback_resume',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gad19d3784fa9a3f5ba2fdf7e57b235d92',1,'cs40l25_event_control_t::playback_resume()'],['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gaf094287eb29e96975be1b302472f2471',1,'cs40l25_event_control_t::@0::@2::playback_resume()']]],
  ['power_837',['power',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga37fa8d396ac536e9780fc567370ddddc',1,'cs40l25_functions_t']]],
  ['power_5fdown_5fsm_838',['power_down_sm',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gafb4e736ee4fe8a367b0e856a6e1f44b7',1,'cs40l25_private_functions_t']]],
  ['power_5fup_5fsm_839',['power_up_sm',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gad1cd49b58c58500e76bc60dac3c8091b',1,'cs40l25_private_functions_t']]],
  ['process_840',['process',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga1ea0a047dcf2a0b103d4c0607eba04fb',1,'cs40l25_functions_t']]]
];
