var searchData=
[
  ['dsp_5fgain_5fcontrol_5freg_5ft_473',['dsp_gain_control_reg_t',['../uniondsp__gain__control__reg__t.html',1,'']]],
  ['dsp_5fgpio_5fbutton_5fdetect_5freg_5ft_474',['dsp_gpio_button_detect_reg_t',['../uniondsp__gpio__button__detect__reg__t.html',1,'']]],
  ['dsp_5freg_5ft_475',['dsp_reg_t',['../uniondsp__reg__t.html',1,'']]]
];
