var searchData=
[
  ['peak_5famplitude_609',['peak_amplitude',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gaee64b2011e609e854ac070b22155be57',1,'cs40l25_dsp_config_controls_t']]]
];
