var searchData=
[
  ['ng_5fdelay_829',['ng_delay',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga00eda1c26e0dbc2062ce7e18de6f7554',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fenable_830',['ng_enable',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga37671285e5cc316267413f2136d58041',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fthld_831',['ng_thld',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga5c7fcca5dc7a65445d40b331047e5e49',1,'cs40l25_audio_hw_config_t']]],
  ['notification_5fcb_832',['notification_cb',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga5a60d7aa7688c330b39cb3cd8ea21d50',1,'cs40l25_config_t']]],
  ['notification_5fcb_5farg_833',['notification_cb_arg',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#gaa5868ae1db251f8092120dc07ede2106',1,'cs40l25_config_t']]]
];
