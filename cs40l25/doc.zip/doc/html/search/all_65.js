var searchData=
[
  ['enable_5firq',['enable_irq',['../structbsp__driver__if__t.html#a4081209f4b505bed6a86e4939485fd4f',1,'bsp_driver_if_t']]],
  ['event_5fcontrol',['event_control',['../group__CS40L25__SM__STATE__.html#gaf68567757c88a623e51d0cda6ae2c122',1,'cs40l25_config_t']]]
];
