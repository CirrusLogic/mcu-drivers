var searchData=
[
  ['get_5fbyte_5ffrom_5fword',['GET_BYTE_FROM_WORD',['../bsp__driver__if_8h.html#a1ab9f1379ee4174ce98b053475fc24ec',1,'bsp_driver_if.h']]],
  ['global_5ffs',['global_fs',['../structcs40l25__clock__config__t.html#a584bca5724799be18ff9546b618499cc',1,'cs40l25_clock_config_t']]],
  ['gp1_5fctrl',['gp1_ctrl',['../structcs40l25__clock__config__t.html#adff32aeb3f7e8007ef5faa7ea18feebe',1,'cs40l25_clock_config_t']]],
  ['gp2_5fctrl',['gp2_ctrl',['../structcs40l25__clock__config__t.html#a99f19d2d38bb16ffacf4c66e2779d9d1',1,'cs40l25_clock_config_t']]]
];
