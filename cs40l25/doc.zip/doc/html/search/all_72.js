var searchData=
[
  ['redc',['redc',['../structcs40l25__calibration__t.html#ab00670eb999614ada71de0ddc8010283',1,'cs40l25_calibration_t']]],
  ['refclk_5ffreq',['refclk_freq',['../structcs40l25__clock__config__t.html#a3b12f053f1d20146de7c161cf48a382a',1,'cs40l25_clock_config_t']]],
  ['refclk_5fsel',['refclk_sel',['../structcs40l25__clock__config__t.html#ac1ce5121caea077804edf4c2d6a8faa1',1,'cs40l25_clock_config_t']]],
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a30af7b0ed7644fb696cfc7e9e918bbda',1,'bsp_driver_if_t']]],
  ['revid',['revid',['../structcs40l25__t.html#a27bfdd3f0ced1f19b7091e60b12c9aff',1,'cs40l25_t']]],
  ['rx1_5fslot',['rx1_slot',['../structcs40l25__asp__config__t.html#a75d61677ce7e8c9242b6a3f0f6ef27e6',1,'cs40l25_asp_config_t']]],
  ['rx2_5fslot',['rx2_slot',['../structcs40l25__asp__config__t.html#a255aea0ca8ecb7db04fd47bd6d176e27',1,'cs40l25_asp_config_t']]],
  ['rx_5fwidth',['rx_width',['../structcs40l25__asp__config__t.html#a77a4f05e12c57152aee4b3b66fdca8e5',1,'cs40l25_asp_config_t']]],
  ['rx_5fwl',['rx_wl',['../structcs40l25__asp__config__t.html#a88f732c9f2d65b0c155901b9d7275ae0',1,'cs40l25_asp_config_t']]]
];
