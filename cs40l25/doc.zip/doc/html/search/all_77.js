var searchData=
[
  ['wksrc_5fgpio1_5fen',['wksrc_gpio1_en',['../structcs40l25__amp__config__t.html#a2bf9f65b6c0a9dbf5d50264d8d9f5b60',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fgpio1_5ffalling_5fedge',['wksrc_gpio1_falling_edge',['../structcs40l25__amp__config__t.html#a52202ab5f8d0862b1cfbff6c2104c00a',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fgpio2_5fen',['wksrc_gpio2_en',['../structcs40l25__amp__config__t.html#a22e6edc08d771359fd215a1263d11d3f',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fgpio2_5ffalling_5fedge',['wksrc_gpio2_falling_edge',['../structcs40l25__amp__config__t.html#a7dc65d096c58bae025e3970020065f23',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fgpio4_5fen',['wksrc_gpio4_en',['../structcs40l25__amp__config__t.html#a40b92314e0938b33f9e48ef9cc295faa',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fgpio4_5ffalling_5fedge',['wksrc_gpio4_falling_edge',['../structcs40l25__amp__config__t.html#a78eebc25d64e88148848bb5068fc9d5c',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fsda_5fen',['wksrc_sda_en',['../structcs40l25__amp__config__t.html#a99045c68212fb21f68579a1529de6795',1,'cs40l25_amp_config_t']]],
  ['wksrc_5fsda_5ffalling_5fedge',['wksrc_sda_falling_edge',['../structcs40l25__amp__config__t.html#a07b0a81b55626c2376ef6464b75ad77e',1,'cs40l25_amp_config_t']]],
  ['wseq_5finitialized',['wseq_initialized',['../structcs40l25__t.html#aa695b9e879355bf176be696e53b4c0b9',1,'cs40l25_t']]],
  ['wseq_5fnum_5fentries',['wseq_num_entries',['../structcs40l25__t.html#aaf2b9a9dcefa8e314aede95e9e39dfdd',1,'cs40l25_t']]]
];
