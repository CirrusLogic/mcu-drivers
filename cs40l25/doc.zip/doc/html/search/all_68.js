var searchData=
[
  ['halo_5fheartbeat',['halo_heartbeat',['../structcs40l25__dsp__status__t.html#adb4a95313439b579cb3de77a98872701',1,'cs40l25_dsp_status_t']]],
  ['halo_5fstate',['halo_state',['../structcs40l25__dsp__status__t.html#a42de57667e9433c2789ebf2ea57eb7c1',1,'cs40l25_dsp_status_t']]]
];
