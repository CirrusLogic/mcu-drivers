var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs40l25_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs40l25.h']]]
];
