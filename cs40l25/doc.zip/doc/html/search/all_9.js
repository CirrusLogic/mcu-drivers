var searchData=
[
  ['ng_5fdelay_342',['ng_delay',['../structcs40l25__audio__hw__config__t.html#a00eda1c26e0dbc2062ce7e18de6f7554',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fenable_343',['ng_enable',['../structcs40l25__audio__hw__config__t.html#a37671285e5cc316267413f2136d58041',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fthld_344',['ng_thld',['../structcs40l25__audio__hw__config__t.html#a5c7fcca5dc7a65445d40b331047e5e49',1,'cs40l25_audio_hw_config_t']]],
  ['notification_5fcb_345',['notification_cb',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga6981ab12d2aedc50e7f30cda2d19d707',1,'cs40l25_bsp_config_t']]],
  ['notification_5fcb_5farg_346',['notification_cb_arg',['../group___c_s40_l25___s_m___s_t_a_t_e__.html#ga8f087271c59e9e5cc70c9410869f5e42',1,'cs40l25_bsp_config_t']]]
];
