var searchData=
[
  ['peak_5famplitude',['peak_amplitude',['../group__CS40L25__SM__STATE__.html#gaee64b2011e609e854ac070b22155be57',1,'cs40l25_dsp_config_controls_t']]]
];
