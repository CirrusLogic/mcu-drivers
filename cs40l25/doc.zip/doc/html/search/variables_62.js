var searchData=
[
  ['backemf',['backemf',['../group__CS40L25__SM__STATE__.html#ga8ae28aa73b023a54c26ec42887c4694a',1,'cs40l25_calibration_t']]],
  ['bclk_5finv',['bclk_inv',['../structcs40l25__audio__hw__config__t.html#aa189fe29a79e729cb0ba926aa6ef9723',1,'cs40l25_audio_hw_config_t']]],
  ['boost_5fcapacitor_5fvalue_5fuf',['boost_capacitor_value_uf',['../structcs40l25__amp__config__t.html#a350be8b7f5048c100e8ef23c8b409c62',1,'cs40l25_amp_config_t']]],
  ['boost_5finductor_5fvalue_5fnh',['boost_inductor_value_nh',['../structcs40l25__amp__config__t.html#aa1f2e1d2c49e9e4c82520b6ec74724e8',1,'cs40l25_amp_config_t']]],
  ['boost_5fipeak_5fma',['boost_ipeak_ma',['../structcs40l25__amp__config__t.html#a665a6d677b6e93b0aa9d8cc6c4cc3cd5',1,'cs40l25_amp_config_t']]],
  ['bsp_5fdev_5fid',['bsp_dev_id',['../group__CS40L25__SM__STATE__.html#ga3734ba37ed35fff1fcd7e20ba25d112e',1,'cs40l25_bsp_config_t']]],
  ['bsp_5fdriver_5fif_5fg',['bsp_driver_if_g',['../bsp__driver__if_8h.html#af9eab00f5b6129ff32f07ba0697df57d',1,'bsp_driver_if.h']]],
  ['bsp_5fint_5fgpio_5fid',['bsp_int_gpio_id',['../group__CS40L25__SM__STATE__.html#ga465bc14a5dbae43d9c124d56583d9e04',1,'cs40l25_bsp_config_t']]],
  ['bsp_5freset_5fgpio_5fid',['bsp_reset_gpio_id',['../group__CS40L25__SM__STATE__.html#ga3a543297762d51fdc1b6a992e095fdbc',1,'cs40l25_bsp_config_t']]],
  ['bst_5fctl',['bst_ctl',['../structcs40l25__amp__config__t.html#a149127679c5d38b5739a61f764d6f453',1,'cs40l25_amp_config_t']]],
  ['bst_5fctl_5flim_5fen',['bst_ctl_lim_en',['../structcs40l25__amp__config__t.html#a337cc72f5c98435634d43b6c3fe33275',1,'cs40l25_amp_config_t']]],
  ['bst_5fctl_5fsel',['bst_ctl_sel',['../structcs40l25__amp__config__t.html#a02f0d3e60c62f2e6d2b8a493cad73605',1,'cs40l25_amp_config_t']]],
  ['bus_5ftype',['bus_type',['../group__CS40L25__SM__STATE__.html#ga2ba144dc1d7bf346e8d3c11c9834f701',1,'cs40l25_bsp_config_t']]]
];
