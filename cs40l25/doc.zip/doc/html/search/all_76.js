var searchData=
[
  ['value',['value',['../structcs40l25__field__accessor__t.html#a79ec325cdaa1e05060cb39d010063613',1,'cs40l25_field_accessor_t::value()'],['../structcs40l25__register__encoding.html#a6560dc1c5a1eadbb5c74558b32be14bb',1,'cs40l25_register_encoding::value()']]],
  ['version_2eh',['version.h',['../version_8h.html',1,'']]],
  ['version_5f',['VERSION_',['../group__VERSION__.html',1,'']]],
  ['version_5fmajor',['VERSION_MAJOR',['../group__VERSION__.html#ga1a53b724b6de666faa8a9e0d06d1055f',1,'version.h']]],
  ['version_5fminor',['VERSION_MINOR',['../group__VERSION__.html#gae0cb52afb79b185b1bf82c7e235f682b',1,'version.h']]],
  ['version_5fpatch',['VERSION_PATCH',['../group__VERSION__.html#ga901edadf17488bb6be1ac9a1e3cfea7a',1,'version.h']]],
  ['volume',['volume',['../structcs40l25__audio__config__t.html#abf28be3eeb1abf34ebf7563116b1dff3',1,'cs40l25_audio_config_t']]]
];
