var searchData=
[
  ['notification_5fcb',['notification_cb',['../structcs40l30__bsp__config__t.html#aa21ae69cc1ce4e70944b53668539fbd2',1,'cs40l30_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs40l30__bsp__config__t.html#ae67ccedb0793486672f9fc692ec08e65',1,'cs40l30_bsp_config_t']]]
];
