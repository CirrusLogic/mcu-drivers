var searchData=
[
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a30af7b0ed7644fb696cfc7e9e918bbda',1,'bsp_driver_if_t']]]
];
