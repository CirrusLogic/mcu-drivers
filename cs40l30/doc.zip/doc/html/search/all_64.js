var searchData=
[
  ['device_5fsyscfg_5fregs_2eh',['device_syscfg_regs.h',['../device__syscfg__regs_8h.html',1,'']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]],
  ['dsp_5freg_5ft',['dsp_reg_t',['../uniondsp__reg__t.html',1,'']]]
];
