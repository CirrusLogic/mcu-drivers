var searchData=
[
  ['set_5fgpio',['set_gpio',['../structbsp__driver__if__t.html#a38f5bb3dc43dac3a2be21ebaecc1b4e9',1,'bsp_driver_if_t']]],
  ['set_5fsupply',['set_supply',['../structbsp__driver__if__t.html#aac04832944c470bb5f8a9bd2ecedc119',1,'bsp_driver_if_t']]],
  ['set_5ftimer',['set_timer',['../structbsp__driver__if__t.html#a8eb8c20cf4919727f96f061622614456',1,'bsp_driver_if_t']]],
  ['spi_5fread',['spi_read',['../structbsp__driver__if__t.html#a196193643a1fefdc2ddcf156f5be2948',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed',['spi_restore_speed',['../structbsp__driver__if__t.html#ab36e63923673f96d28de34a38c282544',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed',['spi_throttle_speed',['../structbsp__driver__if__t.html#aa28f5a31e49560de14cac93e67b06786',1,'bsp_driver_if_t']]],
  ['spi_5fwrite',['spi_write',['../structbsp__driver__if__t.html#a5c482013569bf0983cfa944a6a7b75fb',1,'bsp_driver_if_t']]]
];
