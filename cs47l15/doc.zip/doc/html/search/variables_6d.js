var searchData=
[
  ['mode',['mode',['../structcs47l15__t.html#aaca1e6c823a7bf76e68696367abd3f52',1,'cs47l15_t']]]
];
