var searchData=
[
  ['reg_5fsequence',['reg_sequence',['../structreg__sequence.html',1,'']]],
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a30af7b0ed7644fb696cfc7e9e918bbda',1,'bsp_driver_if_t']]],
  ['revid',['revid',['../structcs47l15__t.html#a6eaf15ea0d7a16a1868838b0007d484c',1,'cs47l15_t']]],
  ['ring_5fbuffer_5fstruct_5ft',['ring_buffer_struct_t',['../group__CS47L15__DSP__.html#ga85fab1ac4fb8d361d6ef05137057fcb1',1,'cs47l15_ext.h']]],
  ['ring_5fbuffer_5ft',['ring_buffer_t',['../structring__buffer__t.html',1,'']]]
];
