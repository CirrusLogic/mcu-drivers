var searchData=
[
  ['cs47l15_5fnotification_5fcallback_5ft',['cs47l15_notification_callback_t',['../cs47l15_8h.html#a4a478fc9c7485c7283d2fc9b5e2632e8',1,'cs47l15.h']]]
];
