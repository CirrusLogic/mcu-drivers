var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs47l15_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs47l15.h']]],
  ['device_5fsyscfg_5fregs_2eh',['device_syscfg_regs.h',['../device__syscfg__regs_8h.html',1,'']]],
  ['devid',['devid',['../structcs47l15__t.html#a41265782174ca1d740b65465cb9c9203',1,'cs47l15_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]],
  ['dsp_5fbuffer_5ft',['dsp_buffer_t',['../group__CS47L15__DSP__.html#ga516f14bf0b0fabe5c972570236ad9d82',1,'cs47l15_ext.h']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l15__dsp__t.html#abad8db5664b14e0b77520a1617dc2b81',1,'cs47l15_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l15__t.html#adaa88eac501c6c55d08f53843c0a49d3',1,'cs47l15_t']]],
  ['dsp_5freg_5ft',['dsp_reg_t',['../uniondsp__reg__t.html',1,'']]],
  ['dsp_5fstruct_5foffsets_5ft',['dsp_struct_offsets_t',['../group__CS47L15__DSP__.html#ga13745ead6870aee4839b6389eaa2b5e6',1,'cs47l15_ext.h']]]
];
