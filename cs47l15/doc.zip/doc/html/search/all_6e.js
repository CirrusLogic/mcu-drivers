var searchData=
[
  ['notification_5fcb',['notification_cb',['../structcs47l15__bsp__config__t.html#af8a9e6a481e2a78517afeecb8ae33cd4',1,'cs47l15_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs47l15__bsp__config__t.html#af47c83043529ac8664334fad55238e9f',1,'cs47l15_bsp_config_t']]]
];
