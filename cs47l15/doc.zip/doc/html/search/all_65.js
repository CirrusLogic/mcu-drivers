var searchData=
[
  ['enable_5firq',['enable_irq',['../structbsp__driver__if__t.html#a4081209f4b505bed6a86e4939485fd4f',1,'bsp_driver_if_t']]],
  ['event_5fflags',['event_flags',['../structcs47l15__t.html#a4b61d8fc2486c8a66e92c7451cbb9ea8',1,'cs47l15_t']]]
];
