var searchData=
[
  ['devid',['devid',['../structcs47l15__t.html#a41265782174ca1d740b65465cb9c9203',1,'cs47l15_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l15__dsp__t.html#abad8db5664b14e0b77520a1617dc2b81',1,'cs47l15_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l15__t.html#adaa88eac501c6c55d08f53843c0a49d3',1,'cs47l15_t']]]
];
