var searchData=
[
  ['fw_5finfo',['fw_info',['../structcs47l15__dsp__t.html#a16bf87f17364a210532c78f3baf9d44f',1,'cs47l15_dsp_t']]]
];
