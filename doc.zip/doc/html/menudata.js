/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Modules",url:"modules.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"e",url:"functions.html#index_e"},
{text:"f",url:"functions.html#index_f"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"m",url:"functions.html#index_m"},
{text:"n",url:"functions.html#index_n"},
{text:"o",url:"functions.html#index_o"},
{text:"q",url:"functions.html#index_q"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"v",url:"functions.html#index_v"},
{text:"w",url:"functions.html#index_w"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"a",url:"functions_vars.html#index_a"},
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"e",url:"functions_vars.html#index_e"},
{text:"f",url:"functions_vars.html#index_f"},
{text:"g",url:"functions_vars.html#index_g"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"m",url:"functions_vars.html#index_m"},
{text:"n",url:"functions_vars.html#index_n"},
{text:"o",url:"functions_vars.html#index_o"},
{text:"q",url:"functions_vars.html#index_q"},
{text:"r",url:"functions_vars.html#index_r"},
{text:"s",url:"functions_vars.html#index_s"},
{text:"v",url:"functions_vars.html#index_v"},
{text:"w",url:"functions_vars.html#index_w"}]}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"File Members",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"b",url:"globals_b.html#index_b"},
{text:"c",url:"globals_c.html#index_c"},
{text:"d",url:"globals_d.html#index_d"},
{text:"f",url:"globals_f.html#index_f"},
{text:"g",url:"globals_g.html#index_g"},
{text:"i",url:"globals_i.html#index_i"},
{text:"m",url:"globals_m.html#index_m"},
{text:"n",url:"globals_n.html#index_n"},
{text:"o",url:"globals_o.html#index_o"},
{text:"p",url:"globals_p.html#index_p"},
{text:"r",url:"globals_r.html#index_r"},
{text:"s",url:"globals_s.html#index_s"},
{text:"t",url:"globals_t.html#index_t"},
{text:"x",url:"globals_x.html#index_x"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"b",url:"globals_func.html#index_b"},
{text:"c",url:"globals_func_c.html#index_c"},
{text:"f",url:"globals_func_f.html#index_f"},
{text:"r",url:"globals_func_r.html#index_r"}]},
{text:"Variables",url:"globals_vars.html",children:[
{text:"b",url:"globals_vars.html#index_b"},
{text:"c",url:"globals_vars.html#index_c"},
{text:"o",url:"globals_vars.html#index_o"}]},
{text:"Typedefs",url:"globals_type.html"},
{text:"Enumerations",url:"globals_enum.html"},
{text:"Macros",url:"globals_defs.html",children:[
{text:"a",url:"globals_defs.html#index_a"},
{text:"b",url:"globals_defs_b.html#index_b"},
{text:"c",url:"globals_defs_c.html#index_c"},
{text:"d",url:"globals_defs_d.html#index_d"},
{text:"g",url:"globals_defs_g.html#index_g"},
{text:"i",url:"globals_defs_i.html#index_i"},
{text:"m",url:"globals_defs_m.html#index_m"},
{text:"n",url:"globals_defs_n.html#index_n"},
{text:"p",url:"globals_defs_p.html#index_p"},
{text:"r",url:"globals_defs_r.html#index_r"},
{text:"s",url:"globals_defs_s.html#index_s"},
{text:"t",url:"globals_defs_t.html#index_t"},
{text:"x",url:"globals_defs_x.html#index_x"}]}]}]}]}
