var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs40l25_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'debug_printf():&#160;cs40l25.h'],['../cs47l15_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'debug_printf():&#160;cs47l15.h'],['../cs47l35_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'debug_printf():&#160;cs47l35.h']]]
];
