var searchData=
[
  ['dsp_5fbuffer_5ft',['dsp_buffer_t',['../group__CS47L15__DSP__.html#ga516f14bf0b0fabe5c972570236ad9d82',1,'dsp_buffer_t():&#160;cs47l15_ext.h'],['../group__CS47L35__DSP__.html#ga516f14bf0b0fabe5c972570236ad9d82',1,'dsp_buffer_t():&#160;cs47l35_ext.h']]]
];
