var searchData=
[
  ['set_5fgpio_1187',['set_gpio',['../structbsp__driver__if__t.html#a70afcf1a76958fba2a8f85dbd220dd83',1,'bsp_driver_if_t']]],
  ['set_5fsupply_1188',['set_supply',['../structbsp__driver__if__t.html#aa399aa589bb0f95732b1710fc97ca3f6',1,'bsp_driver_if_t']]],
  ['set_5ftimer_1189',['set_timer',['../structbsp__driver__if__t.html#a1586994324a4a49f60a116dc6f6d59de',1,'bsp_driver_if_t']]],
  ['shift_1190',['shift',['../structcs35l41__otp__packed__entry__t.html#acd36001363941b78186c99b71c8e04d8',1,'cs35l41_otp_packed_entry_t']]],
  ['size_1191',['size',['../structcs35l41__otp__packed__entry__t.html#a9af1d2d784c543a8dbe9c3b67107e995',1,'cs35l41_otp_packed_entry_t']]],
  ['spi_5fpad_5flen_1192',['spi_pad_len',['../structregmap__cp__config__t.html#aaf02b85872f338609a83379e009ae793',1,'regmap_cp_config_t']]],
  ['spi_5fread_1193',['spi_read',['../structbsp__driver__if__t.html#affa3c679ade482e0bcd09e44e9dc16a9',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed_1194',['spi_restore_speed',['../structbsp__driver__if__t.html#abfcc7cd8c48dcde1b896bd4f7dfed70d',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed_1195',['spi_throttle_speed',['../structbsp__driver__if__t.html#ab79f6761c94f11a643a2e8d22e486128',1,'bsp_driver_if_t']]],
  ['spi_5fwrite_1196',['spi_write',['../structbsp__driver__if__t.html#a5ad22c13d70045408dfcde74b8d7634c',1,'bsp_driver_if_t']]],
  ['state_1197',['state',['../structcs40l25__t.html#a6ad303e9a6f79190e69c869fa07a3a3a',1,'cs40l25_t::state()'],['../structcs47l35__t.html#a0563aaae122b1d85aa12b27d9b904065',1,'cs47l35_t::state()'],['../structcs47l35__dsp__t.html#aff799a7702d12a3d4d0285c280ba0c3c',1,'cs47l35_dsp_t::state()'],['../structcs47l15__t.html#a882c4b5dcc4fe2cbec517263f1292377',1,'cs47l15_t::state()'],['../structcs35l41__t.html#aca3de20e44ac0ee9d1f0932a1114c655',1,'cs35l41_t::state()']]],
  ['syscfg_5fregs_1198',['syscfg_regs',['../structcs35l41__config__t.html#ae8559c7bc8d9ef713d5c8780849bf547',1,'cs35l41_config_t::syscfg_regs()'],['../structcs40l25__config__t.html#a1e45124454632ae22d54d17b7e155320',1,'cs40l25_config_t::syscfg_regs()'],['../structcs47l15__config__t.html#aa83bf3741ba75eced8e0aab3f2c268e9',1,'cs47l15_config_t::syscfg_regs()'],['../structcs47l35__config__t.html#ad59d66d0e5f1a7cf072fdefcba537a46',1,'cs47l35_config_t::syscfg_regs()']]],
  ['syscfg_5fregs_5ftotal_1199',['syscfg_regs_total',['../structcs35l41__config__t.html#a6481d73d919a3327fae95b82deb991c9',1,'cs35l41_config_t::syscfg_regs_total()'],['../structcs40l25__config__t.html#a7f3f0c29c26c0e29031eb460e628e842',1,'cs40l25_config_t::syscfg_regs_total()'],['../structcs47l15__config__t.html#a570aa48f06541c04464d256807b50737',1,'cs47l15_config_t::syscfg_regs_total()'],['../structcs47l35__config__t.html#a77edbcf54766af1e5a483f83f3c87908',1,'cs47l35_config_t::syscfg_regs_total()']]]
];
