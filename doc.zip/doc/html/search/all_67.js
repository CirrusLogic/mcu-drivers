var searchData=
[
  ['get_5fbyte_5ffrom_5fword',['GET_BYTE_FROM_WORD',['../bsp__driver__if_8h.html#a1ab9f1379ee4174ce98b053475fc24ec',1,'bsp_driver_if.h']]],
  ['gpio_5fenable',['gpio_enable',['../structcs40l25__haptic__config__t.html#a4dc14a7966aaac5f5bb4e7bbb4cb07a0',1,'cs40l25_haptic_config_t']]],
  ['gpio_5fgain_5fcontrol',['gpio_gain_control',['../structcs40l25__haptic__config__t.html#a5af0f8d113603373f98ce8f0d312f6f0',1,'cs40l25_haptic_config_t']]],
  ['gpio_5fgpio1_5fctrl1_5freg',['GPIO_GPIO1_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#ga44b29edf597e5501e6670ed6e1853a40',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio2_5fctrl1_5freg',['GPIO_GPIO2_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gaa449bd12d7e4be0829d8bbfa889a3df5',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio3_5fctrl1_5freg',['GPIO_GPIO3_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gae589202f199ee2fd5524eb8dc9de4a65',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio4_5fctrl1_5freg',['GPIO_GPIO4_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gaf280726c503becf2abfe0fd1d5285d01',1,'cs35l41_spec.h']]],
  ['gpio_5fstatus1_5freg',['GPIO_STATUS1_REG',['../group__SECTION__7__20__GPIO.html#ga97b29be77cedf0800baff935135a34e0',1,'cs35l41_spec.h']]],
  ['gpio_5ftrigger_5fconfig',['gpio_trigger_config',['../structcs40l25__haptic__config__t.html#ae925c6adbf16114f203b109ba3b8b21b',1,'cs40l25_haptic_config_t']]]
];
