var searchData=
[
  ['regmap_5fget_5fcp',['REGMAP_GET_CP',['../regmap_8h.html#a01473d6130ccddf27f5d153de88badcc',1,'regmap.h']]]
];
