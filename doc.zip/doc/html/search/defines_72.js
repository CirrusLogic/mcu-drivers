var searchData=
[
  ['regmap_5fget_5fcp_5fconfig',['REGMAP_GET_CP_CONFIG',['../regmap_8h.html#a7f3f95779dd669904111bd4912ea626c',1,'regmap.h']]]
];
