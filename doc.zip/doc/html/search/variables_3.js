var searchData=
[
  ['data_1138',['data',['../structcs35l41__dsp__status__t.html#aeea876f5b4c2a7a770dea3a61b810251',1,'cs35l41_dsp_status_t']]],
  ['dev_5fid_1139',['dev_id',['../structregmap__cp__config__t.html#ac46132d40d3f1e0b96f3fe1e23026baf',1,'regmap_cp_config_t']]],
  ['devid_1140',['devid',['../structcs35l41__t.html#a0388edec69af15368578960ab50d0642',1,'cs35l41_t::devid()'],['../structcs40l25__t.html#ade9fdb65c8601ec85914d910e28720b3',1,'cs40l25_t::devid()'],['../structcs47l15__t.html#a41265782174ca1d740b65465cb9c9203',1,'cs47l15_t::devid()'],['../structcs47l35__t.html#a4e9006e769d7505caa8a446d7f2d7368',1,'cs47l35_t::devid()']]],
  ['disable_5firq_1141',['disable_irq',['../structbsp__driver__if__t.html#ab7dde8dfca33bc4f538539e185c7c840',1,'bsp_driver_if_t']]],
  ['dsp_5fcore_1142',['dsp_core',['../structcs47l15__dsp__t.html#abad8db5664b14e0b77520a1617dc2b81',1,'cs47l15_dsp_t::dsp_core()'],['../structcs47l35__dsp__t.html#a79dfb158e14cf15fc72ca48f29f20955',1,'cs47l35_dsp_t::dsp_core()']]],
  ['dsp_5finfo_1143',['dsp_info',['../structcs47l15__t.html#adaa88eac501c6c55d08f53843c0a49d3',1,'cs47l15_t::dsp_info()'],['../structcs47l35__t.html#a982f7b3c37bd81389f2debc6bff3b9a9',1,'cs47l35_t::dsp_info()']]]
];
