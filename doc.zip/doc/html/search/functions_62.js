var searchData=
[
  ['bridge_5finitialize',['bridge_initialize',['../bridge_8c.html#afb91be35f374e00d0a99881dd407582d',1,'bridge_initialize(bridge_device_t *device_list, uint8_t num_devices):&#160;bridge.c'],['../bridge_8h.html#afb91be35f374e00d0a99881dd407582d',1,'bridge_initialize(bridge_device_t *device_list, uint8_t num_devices):&#160;bridge.c']]],
  ['bridge_5fprocess',['bridge_process',['../bridge_8c.html#af4e4ca92a63f77c9514b211042b47712',1,'bridge_process(void):&#160;bridge.c'],['../bridge_8h.html#af4e4ca92a63f77c9514b211042b47712',1,'bridge_process(void):&#160;bridge.c']]]
];
