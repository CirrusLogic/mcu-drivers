var searchData=
[
  ['dsp_5fstruct_5foffsets_5ft_1212',['dsp_struct_offsets_t',['../group__CS47L15__DSP__.html#ga13745ead6870aee4839b6389eaa2b5e6',1,'dsp_struct_offsets_t():&#160;cs47l15_ext.h'],['../group__CS47L35__DSP__.html#ga13745ead6870aee4839b6389eaa2b5e6',1,'dsp_struct_offsets_t():&#160;cs47l35_ext.h']]]
];
