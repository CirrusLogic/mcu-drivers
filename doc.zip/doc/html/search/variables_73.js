var searchData=
[
  ['set_5fgpio',['set_gpio',['../structbsp__driver__if__t.html#a38f5bb3dc43dac3a2be21ebaecc1b4e9',1,'bsp_driver_if_t']]],
  ['set_5fsupply',['set_supply',['../structbsp__driver__if__t.html#aac04832944c470bb5f8a9bd2ecedc119',1,'bsp_driver_if_t']]],
  ['set_5ftimer',['set_timer',['../structbsp__driver__if__t.html#a8eb8c20cf4919727f96f061622614456',1,'bsp_driver_if_t']]],
  ['shift',['shift',['../structcs35l41__otp__packed__entry__t.html#acd36001363941b78186c99b71c8e04d8',1,'cs35l41_otp_packed_entry_t']]],
  ['size',['size',['../structcs35l41__otp__packed__entry__t.html#a9af1d2d784c543a8dbe9c3b67107e995',1,'cs35l41_otp_packed_entry_t']]],
  ['spi_5fpad_5flen',['spi_pad_len',['../structregmap__cp__config__t.html#aaf02b85872f338609a83379e009ae793',1,'regmap_cp_config_t']]],
  ['spi_5fread',['spi_read',['../structbsp__driver__if__t.html#a196193643a1fefdc2ddcf156f5be2948',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed',['spi_restore_speed',['../structbsp__driver__if__t.html#ab36e63923673f96d28de34a38c282544',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed',['spi_throttle_speed',['../structbsp__driver__if__t.html#aa28f5a31e49560de14cac93e67b06786',1,'bsp_driver_if_t']]],
  ['spi_5fwrite',['spi_write',['../structbsp__driver__if__t.html#a5c482013569bf0983cfa944a6a7b75fb',1,'bsp_driver_if_t']]],
  ['state',['state',['../structcs35l41__t.html#aca3de20e44ac0ee9d1f0932a1114c655',1,'cs35l41_t::state()'],['../structcs40l25__t.html#a6ad303e9a6f79190e69c869fa07a3a3a',1,'cs40l25_t::state()'],['../structcs47l15__t.html#a882c4b5dcc4fe2cbec517263f1292377',1,'cs47l15_t::state()'],['../structcs47l35__dsp__t.html#aff799a7702d12a3d4d0285c280ba0c3c',1,'cs47l35_dsp_t::state()'],['../structcs47l35__t.html#a0563aaae122b1d85aa12b27d9b904065',1,'cs47l35_t::state()']]],
  ['syscfg_5fregs',['syscfg_regs',['../structcs35l41__config__t.html#ae8559c7bc8d9ef713d5c8780849bf547',1,'cs35l41_config_t::syscfg_regs()'],['../structcs40l25__config__t.html#a1e45124454632ae22d54d17b7e155320',1,'cs40l25_config_t::syscfg_regs()'],['../structcs47l15__config__t.html#aa83bf3741ba75eced8e0aab3f2c268e9',1,'cs47l15_config_t::syscfg_regs()'],['../structcs47l35__config__t.html#ad59d66d0e5f1a7cf072fdefcba537a46',1,'cs47l35_config_t::syscfg_regs()']]],
  ['syscfg_5fregs_5ftotal',['syscfg_regs_total',['../structcs35l41__config__t.html#a6481d73d919a3327fae95b82deb991c9',1,'cs35l41_config_t::syscfg_regs_total()'],['../structcs40l25__config__t.html#a7f3f0c29c26c0e29031eb460e628e842',1,'cs40l25_config_t::syscfg_regs_total()'],['../structcs47l15__config__t.html#a570aa48f06541c04464d256807b50737',1,'cs47l15_config_t::syscfg_regs_total()'],['../structcs47l35__config__t.html#a77edbcf54766af1e5a483f83f3c87908',1,'cs47l35_config_t::syscfg_regs_total()']]]
];
