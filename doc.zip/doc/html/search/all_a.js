var searchData=
[
  ['opus_5ftest_5f01_668',['Opus_test_01',['../group__opus__test__01.html',1,'']]],
  ['opus_5ftest_5f01_5f16_2ec_669',['opus_test_01_16.c',['../opus__test__01__16_8c.html',1,'']]],
  ['opus_5ftest_5f01_5f16_2eh_670',['opus_test_01_16.h',['../opus__test__01__16_8h.html',1,'']]],
  ['otp_5fcontents_671',['otp_contents',['../structcs35l41__t.html#a229a9b0a34e00fcb2fb773756e909fb1',1,'cs35l41_t']]],
  ['otp_5fmap_672',['otp_map',['../cs35l41_8c.html#a54724357545386ad61b5b2054526a431',1,'cs35l41.c']]]
];
