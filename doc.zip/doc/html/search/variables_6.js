var searchData=
[
  ['gain_5fcontrol_1152',['gain_control',['../structcs40l25__haptic__config__t.html#afd64ebde032173a41267ed10b0075fd6',1,'cs40l25_haptic_config_t']]],
  ['gpio1_1153',['gpio1',['../unioncs35l41__wakesrc__bits__t.html#aab06018868bb2a99822bececcb9c75c4',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio2_1154',['gpio2',['../unioncs35l41__wakesrc__bits__t.html#a8a5941d14bb417b6192e80c13f213681',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio4_1155',['gpio4',['../unioncs35l41__wakesrc__bits__t.html#a7ba0f89aff1257eed1922c03cea05b0e',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio_5fbutton_5fdetect_1156',['gpio_button_detect',['../structcs40l25__config__t.html#afc6d91a70888aa0b91a9fd39bd92baf9',1,'cs40l25_config_t']]],
  ['gpio_5fenable_1157',['gpio_enable',['../structcs40l25__haptic__config__t.html#ab375b207a1d6de0342da92d6b4fa3a00',1,'cs40l25_haptic_config_t']]]
];
