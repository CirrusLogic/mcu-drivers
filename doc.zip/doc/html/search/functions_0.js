var searchData=
[
  ['bridge_5finitialize_948',['bridge_initialize',['../bridge_8c.html#afb91be35f374e00d0a99881dd407582d',1,'bridge_initialize(bridge_device_t *device_list, uint8_t num_devices):&#160;bridge.c'],['../bridge_8h.html#afb91be35f374e00d0a99881dd407582d',1,'bridge_initialize(bridge_device_t *device_list, uint8_t num_devices):&#160;bridge.c']]],
  ['bridge_5fprocess_949',['bridge_process',['../bridge_8c.html#a960a85ca32fb40d5d82bbf5e1a0cc8fc',1,'bridge_process(void):&#160;bridge.c'],['../bridge_8h.html#a960a85ca32fb40d5d82bbf5e1a0cc8fc',1,'bridge_process(void):&#160;bridge.c']]]
];
