var searchData=
[
  ['ring_5fbuffer_5fstruct_5ft',['ring_buffer_struct_t',['../group__CS47L15__DSP__.html#ga85fab1ac4fb8d361d6ef05137057fcb1',1,'ring_buffer_struct_t():&#160;cs47l15_ext.h'],['../group__CS47L35__DSP__.html#ga85fab1ac4fb8d361d6ef05137057fcb1',1,'ring_buffer_struct_t():&#160;cs47l35_ext.h']]]
];
