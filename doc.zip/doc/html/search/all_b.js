var searchData=
[
  ['pad_5fintf_5fgpio_5fpad_5fcontrol_5freg_673',['PAD_INTF_GPIO_PAD_CONTROL_REG',['../group__SECTION__7__3__PAD__INTF.html#ga0da579a37d947cc28bb8610219412aa8',1,'cs35l41_spec.h']]],
  ['pwrmgmt_5fclassh_5fconfig_5freg_674',['PWRMGMT_CLASSH_CONFIG_REG',['../group__SECTION__7__14__PWRMGMT.html#gad5fa1a369e97cc040c0024290b42dfb9',1,'cs35l41_spec.h']]],
  ['pwrmgmt_5fwkfet_5famp_5fconfig_5freg_675',['PWRMGMT_WKFET_AMP_CONFIG_REG',['../group__SECTION__7__14__PWRMGMT.html#gaa2df1946bbfe6b17fd5a7009ad9b4a45',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fctl_676',['PWRMGT_PWRMGT_CTL',['../group__SECTION__7__4__PWRMGT.html#gad44eb803a0e06245c982b6efe3ec40c5',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fsts_677',['PWRMGT_PWRMGT_STS',['../group__SECTION__7__4__PWRMGT.html#ga52681fc4ddc79dad37589f9c01169649',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fsts_5fwr_5fpendsts_5fbitmask_678',['PWRMGT_PWRMGT_STS_WR_PENDSTS_BITMASK',['../group__SECTION__7__4__PWRMGT.html#gabbf1c7b74e061ba230b4bbe707a9ac96',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fwakesrc_5fctl_679',['PWRMGT_WAKESRC_CTL',['../group__SECTION__7__4__PWRMGT.html#ga1dfb9a87419d1f5b8b0c8a01e1db4310',1,'cs35l41_spec.h']]]
];
