var searchData=
[
  ['arg',['arg',['../structcs47l15__control__request__t.html#a66059cfa70e2004bf3648cffc8b411ef',1,'cs47l15_control_request_t::arg()'],['../structcs47l35__control__request__t.html#a7b203b148e07b9e995d0e52f3e5eb46e',1,'cs47l35_control_request_t::arg()']]]
];
