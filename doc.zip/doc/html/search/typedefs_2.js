var searchData=
[
  ['dsp_5fbuffer_5ft_1209',['dsp_buffer_t',['../group__CS47L15__DSP__.html#gaa9eee06b826225fd26c31a6a68b6ca44',1,'dsp_buffer_t():&#160;cs47l15_ext.h'],['../group__CS47L35__DSP__.html#gaa9eee06b826225fd26c31a6a68b6ca44',1,'dsp_buffer_t():&#160;cs47l35_ext.h']]]
];
