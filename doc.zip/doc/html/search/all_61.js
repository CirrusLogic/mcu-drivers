var searchData=
[
  ['add_5fbyte_5fto_5fword',['ADD_BYTE_TO_WORD',['../bsp__driver__if_8h.html#aee1903c13244accb102ec46aca7d39ee',1,'bsp_driver_if.h']]],
  ['arg',['arg',['../structcs47l15__control__request__t.html#a66059cfa70e2004bf3648cffc8b411ef',1,'cs47l15_control_request_t::arg()'],['../structcs47l35__control__request__t.html#a7b203b148e07b9e995d0e52f3e5eb46e',1,'cs47l35_control_request_t::arg()']]]
];
