var searchData=
[
  ['gain_5fcontrol_596',['gain_control',['../structcs40l25__haptic__config__t.html#afd64ebde032173a41267ed10b0075fd6',1,'cs40l25_haptic_config_t']]],
  ['get_5fbyte_5ffrom_5fword_597',['GET_BYTE_FROM_WORD',['../bsp__driver__if_8h.html#a1ab9f1379ee4174ce98b053475fc24ec',1,'bsp_driver_if.h']]],
  ['gpio1_598',['gpio1',['../unioncs35l41__wakesrc__bits__t.html#aab06018868bb2a99822bececcb9c75c4',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio2_599',['gpio2',['../unioncs35l41__wakesrc__bits__t.html#a8a5941d14bb417b6192e80c13f213681',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio4_600',['gpio4',['../unioncs35l41__wakesrc__bits__t.html#a7ba0f89aff1257eed1922c03cea05b0e',1,'cs35l41_wakesrc_bits_t']]],
  ['gpio_5fbutton_5fdetect_601',['gpio_button_detect',['../structcs40l25__config__t.html#afc6d91a70888aa0b91a9fd39bd92baf9',1,'cs40l25_config_t']]],
  ['gpio_5fenable_602',['gpio_enable',['../structcs40l25__haptic__config__t.html#ab375b207a1d6de0342da92d6b4fa3a00',1,'cs40l25_haptic_config_t']]],
  ['gpio_5fgpio1_5fctrl1_5freg_603',['GPIO_GPIO1_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#ga44b29edf597e5501e6670ed6e1853a40',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio2_5fctrl1_5freg_604',['GPIO_GPIO2_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gaa449bd12d7e4be0829d8bbfa889a3df5',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio3_5fctrl1_5freg_605',['GPIO_GPIO3_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gae589202f199ee2fd5524eb8dc9de4a65',1,'cs35l41_spec.h']]],
  ['gpio_5fgpio4_5fctrl1_5freg_606',['GPIO_GPIO4_CTRL1_REG',['../group__SECTION__7__20__GPIO.html#gaf280726c503becf2abfe0fd1d5285d01',1,'cs35l41_spec.h']]],
  ['gpio_5fstatus1_5freg_607',['GPIO_STATUS1_REG',['../group__SECTION__7__20__GPIO.html#ga97b29be77cedf0800baff935135a34e0',1,'cs35l41_spec.h']]]
];
