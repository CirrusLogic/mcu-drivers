var searchData=
[
  ['gain_5fcontrol',['gain_control',['../structcs40l25__haptic__config__t.html#afd64ebde032173a41267ed10b0075fd6',1,'cs40l25_haptic_config_t']]],
  ['gpio_5fbutton_5fdetect',['gpio_button_detect',['../structcs40l25__config__t.html#afc6d91a70888aa0b91a9fd39bd92baf9',1,'cs40l25_config_t']]],
  ['gpio_5fenable',['gpio_enable',['../structcs40l25__haptic__config__t.html#ab375b207a1d6de0342da92d6b4fa3a00',1,'cs40l25_haptic_config_t']]]
];
