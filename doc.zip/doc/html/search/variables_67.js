var searchData=
[
  ['gpio_5fenable',['gpio_enable',['../structcs40l25__haptic__config__t.html#a4dc14a7966aaac5f5bb4e7bbb4cb07a0',1,'cs40l25_haptic_config_t']]],
  ['gpio_5fgain_5fcontrol',['gpio_gain_control',['../structcs40l25__haptic__config__t.html#a5af0f8d113603373f98ce8f0d312f6f0',1,'cs40l25_haptic_config_t']]],
  ['gpio_5ftrigger_5fconfig',['gpio_trigger_config',['../structcs40l25__haptic__config__t.html#ae925c6adbf16114f203b109ba3b8b21b',1,'cs40l25_haptic_config_t']]]
];
