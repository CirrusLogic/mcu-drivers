var searchData=
[
  ['enable_1144',['enable',['../structcs35l41__wakesrc__ctrl__t.html#a98705672cae680485359ba2c72eae339',1,'cs35l41_wakesrc_ctrl_t']]],
  ['enable_5firq_1145',['enable_irq',['../structbsp__driver__if__t.html#acc9c058938adde4ff740af1eb640af5b',1,'bsp_driver_if_t']]],
  ['event_5fcontrol_1146',['event_control',['../structcs40l25__config__t.html#af68567757c88a623e51d0cda6ae2c122',1,'cs40l25_config_t']]],
  ['event_5fflags_1147',['event_flags',['../structcs35l41__t.html#a320f0f37a4c0a74b9e1cf7ef8560746f',1,'cs35l41_t::event_flags()'],['../structcs40l25__t.html#aaac6b68b36c6a9a53ea80f85fd54f6a6',1,'cs40l25_t::event_flags()'],['../structcs47l15__t.html#a4b61d8fc2486c8a66e92c7451cbb9ea8',1,'cs47l15_t::event_flags()'],['../structcs47l35__t.html#a9fe82128c95ed286f07ea0aaec9a5ebc',1,'cs47l35_t::event_flags()']]]
];
