var searchData=
[
  ['wakesrc_5fctrl_777',['wakesrc_ctrl',['../structcs35l41__config__t.html#a464917a6beea84069462335e60462fd8',1,'cs35l41_config_t']]],
  ['wseq_5finitialized_778',['wseq_initialized',['../structcs40l25__t.html#aa695b9e879355bf176be696e53b4c0b9',1,'cs40l25_t']]],
  ['wseq_5fnum_5fentries_779',['wseq_num_entries',['../structcs40l25__t.html#aaf2b9a9dcefa8e314aede95e9e39dfdd',1,'cs40l25_t']]]
];
