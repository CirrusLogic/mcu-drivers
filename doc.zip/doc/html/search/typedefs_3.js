var searchData=
[
  ['ring_5fbuffer_5fstruct_5ft_1210',['ring_buffer_struct_t',['../group__CS47L15__DSP__.html#ga20d9035fbf5961771dc7062c52501fcc',1,'ring_buffer_struct_t():&#160;cs47l15_ext.h'],['../group__CS47L35__DSP__.html#ga20d9035fbf5961771dc7062c52501fcc',1,'ring_buffer_struct_t():&#160;cs47l35_ext.h']]]
];
