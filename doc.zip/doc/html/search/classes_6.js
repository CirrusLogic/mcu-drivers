var searchData=
[
  ['scc_5fconfig_5ft_911',['scc_config_t',['../structscc__config__t.html',1,'']]],
  ['scc_5ft_912',['scc_t',['../structscc__t.html',1,'']]]
];
