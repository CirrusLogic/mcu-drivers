var searchData=
[
  ['set_5fgpio',['set_gpio',['../structbsp__driver__if__t.html#a38f5bb3dc43dac3a2be21ebaecc1b4e9',1,'bsp_driver_if_t']]],
  ['set_5fsupply',['set_supply',['../structbsp__driver__if__t.html#aac04832944c470bb5f8a9bd2ecedc119',1,'bsp_driver_if_t']]],
  ['set_5ftimer',['set_timer',['../structbsp__driver__if__t.html#a8eb8c20cf4919727f96f061622614456',1,'bsp_driver_if_t']]],
  ['spi_5fread',['spi_read',['../structbsp__driver__if__t.html#a196193643a1fefdc2ddcf156f5be2948',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed',['spi_restore_speed',['../structbsp__driver__if__t.html#ab36e63923673f96d28de34a38c282544',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed',['spi_throttle_speed',['../structbsp__driver__if__t.html#aa28f5a31e49560de14cac93e67b06786',1,'bsp_driver_if_t']]],
  ['spi_5fwrite',['spi_write',['../structbsp__driver__if__t.html#a5c482013569bf0983cfa944a6a7b75fb',1,'bsp_driver_if_t']]],
  ['state',['state',['../structcs47l35__dsp__t.html#aff799a7702d12a3d4d0285c280ba0c3c',1,'cs47l35_dsp_t::state()'],['../structcs47l35__t.html#a0563aaae122b1d85aa12b27d9b904065',1,'cs47l35_t::state()']]],
  ['syscfg_5freg_5fdescriptor_5ft',['syscfg_reg_descriptor_t',['../structsyscfg__reg__descriptor__t.html',1,'']]],
  ['syscfg_5freg_5flist_5fentry_5ft',['syscfg_reg_list_entry_t',['../structsyscfg__reg__list__entry__t.html',1,'']]],
  ['syscfg_5fregs',['syscfg_regs',['../structcs47l35__config__t.html#a4461828a1a7634615f5d4b1441e6b2f8',1,'cs47l35_config_t']]],
  ['syscfg_5fregs_5ftotal',['syscfg_regs_total',['../structcs47l35__config__t.html#a77edbcf54766af1e5a483f83f3c87908',1,'cs47l35_config_t']]]
];
