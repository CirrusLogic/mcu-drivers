var searchData=
[
  ['notification_5fcb',['notification_cb',['../structcs47l35__bsp__config__t.html#a5d00e92f171d504e939ff3985dcd03cc',1,'cs47l35_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs47l35__bsp__config__t.html#ac4479cdb119f2ea3f661332f338f9927',1,'cs47l35_bsp_config_t']]]
];
