var searchData=
[
  ['cs47l35_5fnotification_5fcallback_5ft',['cs47l35_notification_callback_t',['../cs47l35_8h.html#a7a439f3ac799c5cab759948e06598c67',1,'cs47l35.h']]]
];
