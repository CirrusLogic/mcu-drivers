var searchData=
[
  ['base_5faddr',['base_addr',['../structcs47l35__dsp__t.html#aabffd9fcd6d6f89c487ff9c37de44fec',1,'cs47l35_dsp_t']]],
  ['bsp_5fconfig',['bsp_config',['../structcs47l35__config__t.html#aaad73280ec7f2ec68cffc18119419f0a',1,'cs47l35_config_t']]],
  ['bsp_5fdcvdd_5fsupply_5fid',['bsp_dcvdd_supply_id',['../structcs47l35__bsp__config__t.html#a803c54d7c472e4543c7ffe0103d79330',1,'cs47l35_bsp_config_t']]],
  ['bsp_5fdev_5fid',['bsp_dev_id',['../structcs47l35__bsp__config__t.html#aed7f4a4d833a1b36f113ba24348ff467',1,'cs47l35_bsp_config_t']]],
  ['bsp_5fdriver_5fif_5fg',['bsp_driver_if_g',['../bsp__driver__if_8h.html#af9eab00f5b6129ff32f07ba0697df57d',1,'bsp_driver_if.h']]],
  ['bsp_5fint_5fgpio_5fid',['bsp_int_gpio_id',['../structcs47l35__bsp__config__t.html#a28c487db21e9943c90c19049ca3e5341',1,'cs47l35_bsp_config_t']]],
  ['bsp_5freset_5fgpio_5fid',['bsp_reset_gpio_id',['../structcs47l35__bsp__config__t.html#ac65c6770ebc7f3fbb6ea3bae140d9404',1,'cs47l35_bsp_config_t']]],
  ['bus_5ftype',['bus_type',['../structcs47l35__bsp__config__t.html#a3b4608ee06dced6a65fe45c43fdc6846',1,'cs47l35_bsp_config_t']]]
];
