var searchData=
[
  ['mode',['mode',['../structcs47l35__t.html#a14e4bdbf1b2b723b8029f7ba0d24e7b3',1,'cs47l35_t']]]
];
