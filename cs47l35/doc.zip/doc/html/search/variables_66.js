var searchData=
[
  ['fw_5finfo',['fw_info',['../structcs47l35__dsp__t.html#ad0db33ec3375b1d934a84c87d6408a7f',1,'cs47l35_dsp_t']]]
];
