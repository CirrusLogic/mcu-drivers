var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs47l35_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs47l35.h']]]
];
