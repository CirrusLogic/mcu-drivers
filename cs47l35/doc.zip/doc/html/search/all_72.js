var searchData=
[
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a30af7b0ed7644fb696cfc7e9e918bbda',1,'bsp_driver_if_t']]],
  ['revid',['revid',['../structcs47l35__t.html#a5efad25e77a7e6c23c4daff542b00647',1,'cs47l35_t']]],
  ['ring_5fbuffer_5fstruct_5ft',['ring_buffer_struct_t',['../group__CS47L35__DSP__.html#ga85fab1ac4fb8d361d6ef05137057fcb1',1,'cs47l35_ext.h']]],
  ['ring_5fbuffer_5ft',['ring_buffer_t',['../structring__buffer__t.html',1,'']]]
];
