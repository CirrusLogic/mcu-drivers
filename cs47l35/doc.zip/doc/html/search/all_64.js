var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs47l35_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs47l35.h']]],
  ['device_5fsyscfg_5fregs_2eh',['device_syscfg_regs.h',['../device__syscfg__regs_8h.html',1,'']]],
  ['devid',['devid',['../structcs47l35__t.html#a4e9006e769d7505caa8a446d7f2d7368',1,'cs47l35_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]],
  ['dsp_5fbuffer_5ft',['dsp_buffer_t',['../group__CS47L35__DSP__.html#ga516f14bf0b0fabe5c972570236ad9d82',1,'cs47l35_ext.h']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l35__dsp__t.html#a79dfb158e14cf15fc72ca48f29f20955',1,'cs47l35_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l35__t.html#a982f7b3c37bd81389f2debc6bff3b9a9',1,'cs47l35_t']]],
  ['dsp_5freg_5ft',['dsp_reg_t',['../uniondsp__reg__t.html',1,'']]],
  ['dsp_5fstruct_5foffsets_5ft',['dsp_struct_offsets_t',['../group__CS47L35__DSP__.html#ga13745ead6870aee4839b6389eaa2b5e6',1,'cs47l35_ext.h']]]
];
