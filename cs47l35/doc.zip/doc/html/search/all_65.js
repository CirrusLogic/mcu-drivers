var searchData=
[
  ['enable_5firq',['enable_irq',['../structbsp__driver__if__t.html#a4081209f4b505bed6a86e4939485fd4f',1,'bsp_driver_if_t']]],
  ['event_5fflags',['event_flags',['../structcs47l35__t.html#a9fe82128c95ed286f07ea0aaec9a5ebc',1,'cs47l35_t']]]
];
