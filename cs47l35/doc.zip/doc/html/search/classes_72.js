var searchData=
[
  ['ring_5fbuffer_5ft',['ring_buffer_t',['../structring__buffer__t.html',1,'']]]
];
