var searchData=
[
  ['devid',['devid',['../structcs47l35__t.html#a4e9006e769d7505caa8a446d7f2d7368',1,'cs47l35_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l35__dsp__t.html#a79dfb158e14cf15fc72ca48f29f20955',1,'cs47l35_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l35__t.html#a982f7b3c37bd81389f2debc6bff3b9a9',1,'cs47l35_t']]]
];
