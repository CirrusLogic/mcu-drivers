var searchData=
[
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a30af7b0ed7644fb696cfc7e9e918bbda',1,'bsp_driver_if_t']]],
  ['revid',['revid',['../structcs47l35__t.html#a5efad25e77a7e6c23c4daff542b00647',1,'cs47l35_t']]]
];
