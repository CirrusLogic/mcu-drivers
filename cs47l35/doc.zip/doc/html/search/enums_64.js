var searchData=
[
  ['dsp_5fstruct_5foffsets_5ft',['dsp_struct_offsets_t',['../group__CS47L35__DSP__.html#ga13745ead6870aee4839b6389eaa2b5e6',1,'cs47l35_ext.h']]]
];
