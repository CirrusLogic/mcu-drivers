var searchData=
[
  ['validate_5fboot_5fconfig_477',['validate_boot_config',['../structcs35l41__private__functions__t.html#a3a9fe55eb9babd92801872db7df24b8f',1,'cs35l41_private_functions_t']]],
  ['value_478',['value',['../structcs35l41__field__accessor__t.html#a518e0341ecd6710226011358e8caca1e',1,'cs35l41_field_accessor_t::value()'],['../structcs35l41__register__encoding.html#af9b51134512370ce290d4c2be97f0e12',1,'cs35l41_register_encoding::value()']]],
  ['version_2eh_479',['version.h',['../version_8h.html',1,'']]],
  ['version_5f_480',['VERSION_',['../group___v_e_r_s_i_o_n__.html',1,'']]],
  ['version_5fmajor_481',['VERSION_MAJOR',['../group___v_e_r_s_i_o_n__.html#ga1a53b724b6de666faa8a9e0d06d1055f',1,'version.h']]],
  ['version_5fminor_482',['VERSION_MINOR',['../group___v_e_r_s_i_o_n__.html#gae0cb52afb79b185b1bf82c7e235f682b',1,'version.h']]],
  ['version_5fpatch_483',['VERSION_PATCH',['../group___v_e_r_s_i_o_n__.html#ga901edadf17488bb6be1ac9a1e3cfea7a',1,'version.h']]],
  ['vimon_5fspkmon_5fresync_5freg_484',['VIMON_SPKMON_RESYNC_REG',['../group___s_e_c_t_i_o_n__7__12___v_i_m_o_n.html#ga1508cf19644cecc599c19be0265b7ea7',1,'cs35l41_spec.h']]],
  ['volume_485',['volume',['../structcs35l41__audio__config__t.html#a94fdb687b172e8cc6bbf68203d11cb63',1,'cs35l41_audio_config_t']]]
];
