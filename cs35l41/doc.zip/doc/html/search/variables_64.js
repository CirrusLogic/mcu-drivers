var searchData=
[
  ['data',['data',['../structcs35l41__dsp__status__t.html#af9197e137303112f6913506e00562824',1,'cs35l41_dsp_status_t']]],
  ['devid',['devid',['../structcs35l41__t.html#a0388edec69af15368578960ab50d0642',1,'cs35l41_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]]
];
