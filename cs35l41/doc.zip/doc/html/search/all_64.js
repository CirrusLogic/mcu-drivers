var searchData=
[
  ['data',['data',['../structcs35l41__dsp__status__t.html#af9197e137303112f6913506e00562824',1,'cs35l41_dsp_status_t']]],
  ['dataif_5fasp_5fcontrol1_5freg',['DATAIF_ASP_CONTROL1_REG',['../group__SECTION__7__10__DATAIF.html#ga61f706993a742f8d36b8197e5bddae59',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fcontrol2_5freg',['DATAIF_ASP_CONTROL2_REG',['../group__SECTION__7__10__DATAIF.html#gaf893c84c2f8ab87601391d28b930a19e',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fcontrol3_5freg',['DATAIF_ASP_CONTROL3_REG',['../group__SECTION__7__10__DATAIF.html#gaf79d69f57ca452b90c7645424a6a6817',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fdata_5fcontrol1_5freg',['DATAIF_ASP_DATA_CONTROL1_REG',['../group__SECTION__7__10__DATAIF.html#gad5397deac0c4b92a4c1fd75716595761',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fdata_5fcontrol5_5freg',['DATAIF_ASP_DATA_CONTROL5_REG',['../group__SECTION__7__10__DATAIF.html#ga0d3f859268e1e0e166294daa7e645548',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fenables1_5freg',['DATAIF_ASP_ENABLES1_REG',['../group__SECTION__7__10__DATAIF.html#ga2ba348d1c599504cf7f375f367060773',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fframe_5fcontrol1_5freg',['DATAIF_ASP_FRAME_CONTROL1_REG',['../group__SECTION__7__10__DATAIF.html#ga13238096ad1b0ab56635b52de656337b',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fframe_5fcontrol5_5freg',['DATAIF_ASP_FRAME_CONTROL5_REG',['../group__SECTION__7__10__DATAIF.html#ga4b66bfa908de550effe58c598f7b53f7',1,'cs35l41_spec.h']]],
  ['device_5fsyscfg_5fregs_2eh',['device_syscfg_regs.h',['../device__syscfg__regs_8h.html',1,'']]],
  ['devid',['devid',['../structcs35l41__t.html#a0388edec69af15368578960ab50d0642',1,'cs35l41_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#a9cd6092b87b403929fa9f6d15e2a2ef3',1,'bsp_driver_if_t']]]
];
