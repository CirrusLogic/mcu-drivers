var searchData=
[
  ['enable_5firq_232',['enable_irq',['../structbsp__driver__if__t.html#acc9c058938adde4ff740af1eb640af5b',1,'bsp_driver_if_t']]],
  ['event_5fflags_233',['event_flags',['../structcs35l41__t.html#a320f0f37a4c0a74b9e1cf7ef8560746f',1,'cs35l41_t']]]
];
