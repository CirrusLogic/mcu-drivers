var searchData=
[
  ['i2c_5fdb_5fwrite',['i2c_db_write',['../structbsp__driver__if__t.html#acf2afdab46ce6b262990c3ebc6317a65',1,'bsp_driver_if_t']]],
  ['i2c_5fread_5frepeated_5fstart',['i2c_read_repeated_start',['../structbsp__driver__if__t.html#a77efa0d2816b5dcff7b7a69c06406029',1,'bsp_driver_if_t']]],
  ['i2c_5freset',['i2c_reset',['../structbsp__driver__if__t.html#a83ea0eedbb89ba9aaf8622e011a922cd',1,'bsp_driver_if_t']]],
  ['i2c_5fwrite',['i2c_write',['../structbsp__driver__if__t.html#a1e1812b848e88d0d24a91f3997ad5e29',1,'bsp_driver_if_t']]],
  ['id',['id',['../structcs35l41__field__accessor__t.html#a0a944c96b5cd8ba96effd4efb7c26089',1,'cs35l41_field_accessor_t::id()'],['../structcs35l41__otp__map__t.html#abfb084ee1557a590b545aa30e47bc8fe',1,'cs35l41_otp_map_t::id()'],['../structcs35l41__control__request__t.html#a90c39c2464c515d4196910cc115c3db8',1,'cs35l41_control_request_t::id()']]],
  ['is_5fcal_5fboot',['is_cal_boot',['../structcs35l41__t.html#a115b9721f48cf5723df1f9865d276079',1,'cs35l41_t']]],
  ['is_5fcalibration_5fapplied',['is_calibration_applied',['../structcs35l41__dsp__status__t.html#a7ec43b2bc8ad2eec814c4eb2c0b84a95',1,'cs35l41_dsp_status_t']]],
  ['is_5fhb_5finc',['is_hb_inc',['../structcs35l41__dsp__status__t.html#a88758da6453fa5b4fcdcce5095a1fc2f',1,'cs35l41_dsp_status_t']]],
  ['is_5fi2s',['is_i2s',['../structcs35l41__asp__config__t.html#a2aaa235665d0883baa1dd9749acbba25',1,'cs35l41_asp_config_t']]],
  ['is_5fmaster_5fmode',['is_master_mode',['../structcs35l41__audio__hw__config__t.html#a5f72b95276e9c85970e705f48edd37e3',1,'cs35l41_audio_hw_config_t']]],
  ['is_5ftemp_5fchanged',['is_temp_changed',['../structcs35l41__dsp__status__t.html#a90111451c76ae4084065d81df1cbe684',1,'cs35l41_dsp_status_t']]],
  ['is_5fvalid',['is_valid',['../structcs35l41__calibration__t.html#a6efa919cf3e1f3122182a736a836f85c',1,'cs35l41_calibration_t']]]
];
