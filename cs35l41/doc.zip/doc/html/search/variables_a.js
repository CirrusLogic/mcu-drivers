var searchData=
[
  ['ng_5fdelay_760',['ng_delay',['../structcs35l41__audio__hw__config__t.html#a54399f563d1da0d7922a0a9cfd14c57a',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fenable_761',['ng_enable',['../structcs35l41__audio__hw__config__t.html#acd78ec8c313e52e8fb3a261a1a6cc1c5',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fthld_762',['ng_thld',['../structcs35l41__audio__hw__config__t.html#a9628272a002d6aa9026e0623a1721700',1,'cs35l41_audio_hw_config_t']]],
  ['notification_5fcb_763',['notification_cb',['../structcs35l41__config__t.html#a7562acad6414c221191f352ec56aa8cd',1,'cs35l41_config_t']]],
  ['notification_5fcb_5farg_764',['notification_cb_arg',['../structcs35l41__config__t.html#a7ccab286b6bca636dabf0a7902dbabdd',1,'cs35l41_config_t']]],
  ['num_5felements_765',['num_elements',['../structcs35l41__otp__map__t.html#a72880309bbc485113108f5613d06e978',1,'cs35l41_otp_map_t']]]
];
