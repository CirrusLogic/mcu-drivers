var searchData=
[
  ['value_612',['value',['../structcs35l41__field__accessor__t.html#a518e0341ecd6710226011358e8caca1e',1,'cs35l41_field_accessor_t::value()'],['../structcs35l41__register__encoding.html#af9b51134512370ce290d4c2be97f0e12',1,'cs35l41_register_encoding::value()']]],
  ['volume_613',['volume',['../structcs35l41__audio__config__t.html#a94fdb687b172e8cc6bbf68203d11cb63',1,'cs35l41_audio_config_t']]]
];
