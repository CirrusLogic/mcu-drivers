var searchData=
[
  ['enable_5firq',['enable_irq',['../structbsp__driver__if__t.html#a4081209f4b505bed6a86e4939485fd4f',1,'bsp_driver_if_t']]],
  ['event_5fflags',['event_flags',['../structcs35l41__t.html#a320f0f37a4c0a74b9e1cf7ef8560746f',1,'cs35l41_t']]]
];
