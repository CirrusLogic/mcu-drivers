var searchData=
[
  ['wkfet_5famp_5fdelay_808',['wkfet_amp_delay',['../structcs35l41__amp__config__t.html#a29900d8e62dd8b55d16b2ee787b5e2e5',1,'cs35l41_amp_config_t']]],
  ['wkfet_5famp_5fthld_809',['wkfet_amp_thld',['../structcs35l41__amp__config__t.html#abc73ad97278295c0bbd226e1656c1821',1,'cs35l41_amp_config_t']]],
  ['write_5freg_810',['write_reg',['../structcs35l41__private__functions__t.html#a4410e22074eeece6f37c48f8369067dd',1,'cs35l41_private_functions_t']]]
];
