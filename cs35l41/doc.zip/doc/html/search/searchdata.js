var indexSectionsWithContent =
{
  0: "abcdefgimnoprstv",
  1: "bcfs",
  2: "bcdf",
  3: "cf",
  4: "abcdefimnorsv",
  5: "bc",
  6: "c",
  7: "abcg",
  8: "bcfs",
  9: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

