var searchData=
[
  ['pad_5fintf_5fgpio_5fpad_5fcontrol_5freg_328',['PAD_INTF_GPIO_PAD_CONTROL_REG',['../group___s_e_c_t_i_o_n__7__3___p_a_d___i_n_t_f.html#ga0da579a37d947cc28bb8610219412aa8',1,'cs35l41_spec.h']]],
  ['pwrmgmt_5fclassh_5fconfig_5freg_329',['PWRMGMT_CLASSH_CONFIG_REG',['../group___s_e_c_t_i_o_n__7__14___p_w_r_m_g_m_t.html#gad5fa1a369e97cc040c0024290b42dfb9',1,'cs35l41_spec.h']]],
  ['pwrmgmt_5fwkfet_5famp_5fconfig_5freg_330',['PWRMGMT_WKFET_AMP_CONFIG_REG',['../group___s_e_c_t_i_o_n__7__14___p_w_r_m_g_m_t.html#gaa2df1946bbfe6b17fd5a7009ad9b4a45',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fctl_331',['PWRMGT_PWRMGT_CTL',['../group___s_e_c_t_i_o_n__7__4___p_w_r_m_g_t.html#gad44eb803a0e06245c982b6efe3ec40c5',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fsts_332',['PWRMGT_PWRMGT_STS',['../group___s_e_c_t_i_o_n__7__4___p_w_r_m_g_t.html#ga52681fc4ddc79dad37589f9c01169649',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fpwrmgt_5fsts_5fwr_5fpendsts_5fbitmask_333',['PWRMGT_PWRMGT_STS_WR_PENDSTS_BITMASK',['../group___s_e_c_t_i_o_n__7__4___p_w_r_m_g_t.html#gabbf1c7b74e061ba230b4bbe707a9ac96',1,'cs35l41_spec.h']]],
  ['pwrmgt_5fwakesrc_5fctl_334',['PWRMGT_WAKESRC_CTL',['../group___s_e_c_t_i_o_n__7__4___p_w_r_m_g_t.html#ga1dfb9a87419d1f5b8b0c8a01e1db4310',1,'cs35l41_spec.h']]]
];
