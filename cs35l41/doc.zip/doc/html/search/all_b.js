var searchData=
[
  ['ng_5fdelay_399',['ng_delay',['../structcs35l41__audio__hw__config__t.html#a54399f563d1da0d7922a0a9cfd14c57a',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fenable_400',['ng_enable',['../structcs35l41__audio__hw__config__t.html#acd78ec8c313e52e8fb3a261a1a6cc1c5',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fthld_401',['ng_thld',['../structcs35l41__audio__hw__config__t.html#a9628272a002d6aa9026e0623a1721700',1,'cs35l41_audio_hw_config_t']]],
  ['noise_5fgate_5fmixer_5fngate_5fch1_5fcfg_5freg_402',['NOISE_GATE_MIXER_NGATE_CH1_CFG_REG',['../group___s_e_c_t_i_o_n__7__26___n_o_i_s_e___g_a_t_e.html#gaca035e6f07aede96068a6cd588338c4d',1,'cs35l41_spec.h']]],
  ['noise_5fgate_5fmixer_5fngate_5fch2_5fcfg_5freg_403',['NOISE_GATE_MIXER_NGATE_CH2_CFG_REG',['../group___s_e_c_t_i_o_n__7__26___n_o_i_s_e___g_a_t_e.html#gacb3c3083fce4718e4cf35f47a59ad9ab',1,'cs35l41_spec.h']]],
  ['notification_5fcb_404',['notification_cb',['../structcs35l41__config__t.html#a7562acad6414c221191f352ec56aa8cd',1,'cs35l41_config_t']]],
  ['notification_5fcb_5farg_405',['notification_cb_arg',['../structcs35l41__config__t.html#a7ccab286b6bca636dabf0a7902dbabdd',1,'cs35l41_config_t']]],
  ['num_5felements_406',['num_elements',['../structcs35l41__otp__map__t.html#a72880309bbc485113108f5613d06e978',1,'cs35l41_otp_map_t']]]
];
