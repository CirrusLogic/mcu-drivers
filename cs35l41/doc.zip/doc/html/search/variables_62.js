var searchData=
[
  ['bit_5foffset',['bit_offset',['../structcs35l41__otp__map__t.html#a7995c39d3359671f22bb1f4216e08306',1,'cs35l41_otp_map_t']]],
  ['bsp_5fconfig',['bsp_config',['../structcs35l41__config__t.html#a5ab820bb6a4f0f8d416b0e06e06ef250',1,'cs35l41_config_t']]],
  ['bsp_5fdev_5fid',['bsp_dev_id',['../structcs35l41__bsp__config__t.html#a5efc0445a421d93cb6d137ef92682442',1,'cs35l41_bsp_config_t']]],
  ['bsp_5fdriver_5fif_5fg',['bsp_driver_if_g',['../bsp__driver__if_8h.html#af9eab00f5b6129ff32f07ba0697df57d',1,'bsp_driver_if.h']]],
  ['bsp_5fint_5fgpio_5fid',['bsp_int_gpio_id',['../structcs35l41__bsp__config__t.html#a501bd7846a9024571f8942e18b34c30b',1,'cs35l41_bsp_config_t']]],
  ['bsp_5freset_5fgpio_5fid',['bsp_reset_gpio_id',['../structcs35l41__bsp__config__t.html#a480555b8baaafef0cfd1ae7931317408',1,'cs35l41_bsp_config_t']]],
  ['bus_5ftype',['bus_type',['../structcs35l41__bsp__config__t.html#a268c036cb877a26308af9e0187ee0869',1,'cs35l41_bsp_config_t']]]
];
