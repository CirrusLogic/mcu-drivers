var searchData=
[
  ['ng_5fdelay',['ng_delay',['../structcs35l41__audio__hw__config__t.html#a54399f563d1da0d7922a0a9cfd14c57a',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fenable',['ng_enable',['../structcs35l41__audio__hw__config__t.html#acd78ec8c313e52e8fb3a261a1a6cc1c5',1,'cs35l41_audio_hw_config_t']]],
  ['ng_5fthld',['ng_thld',['../structcs35l41__audio__hw__config__t.html#a9628272a002d6aa9026e0623a1721700',1,'cs35l41_audio_hw_config_t']]],
  ['notification_5fcb',['notification_cb',['../structcs35l41__bsp__config__t.html#a6de32f205ae46c1ec1a8aaf5a331157b',1,'cs35l41_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs35l41__bsp__config__t.html#aa5b5137e0d56f4ab77c799ae6910dcc7',1,'cs35l41_bsp_config_t']]],
  ['num_5felements',['num_elements',['../structcs35l41__otp__map__t.html#a72880309bbc485113108f5613d06e978',1,'cs35l41_otp_map_t']]]
];
