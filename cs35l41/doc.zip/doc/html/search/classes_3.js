var searchData=
[
  ['syscfg_5freg_5flist_5fentry_5ft_508',['syscfg_reg_list_entry_t',['../structsyscfg__reg__list__entry__t.html',1,'']]],
  ['syscfg_5freg_5ft_509',['syscfg_reg_t',['../structsyscfg__reg__t.html',1,'']]]
];
