var searchData=
[
  ['temp_5fwarn_5fthld',['temp_warn_thld',['../structcs35l41__amp__config__t.html#ac0116bc4fca61c1d827b3c81c3824fc0',1,'cs35l41_amp_config_t']]],
  ['tx1_5fslot',['tx1_slot',['../structcs35l41__asp__config__t.html#a8864e7fcd18764f41e7139820e84d058',1,'cs35l41_asp_config_t']]],
  ['tx2_5fslot',['tx2_slot',['../structcs35l41__asp__config__t.html#a105538622de58f437d46323e29e630f9',1,'cs35l41_asp_config_t']]],
  ['tx3_5fslot',['tx3_slot',['../structcs35l41__asp__config__t.html#a7b9a9cb492cf51fa164388e3a4522c5e',1,'cs35l41_asp_config_t']]],
  ['tx4_5fslot',['tx4_slot',['../structcs35l41__asp__config__t.html#aa57d4eae1c9a59b1790d225ea4de536e',1,'cs35l41_asp_config_t']]],
  ['tx_5fwidth',['tx_width',['../structcs35l41__asp__config__t.html#adf8ad5f9d03304de3c21b83b28ba6d98',1,'cs35l41_asp_config_t']]],
  ['tx_5fwl',['tx_wl',['../structcs35l41__asp__config__t.html#a46e1d2df184b2dcc82d5a1264553d611',1,'cs35l41_asp_config_t']]]
];
