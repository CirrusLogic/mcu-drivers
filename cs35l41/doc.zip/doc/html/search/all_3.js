var searchData=
[
  ['dac_5fsrc_230',['dac_src',['../structcs35l41__routing__config__t.html#a92b75e1d8731468e466a348165b9e9ee',1,'cs35l41_routing_config_t']]],
  ['data_231',['data',['../structcs35l41__dsp__status__t.html#af9197e137303112f6913506e00562824',1,'cs35l41_dsp_status_t']]],
  ['dataif_5fasp_5fcontrol1_5freg_232',['DATAIF_ASP_CONTROL1_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#ga61f706993a742f8d36b8197e5bddae59',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fcontrol2_5freg_233',['DATAIF_ASP_CONTROL2_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#gaf893c84c2f8ab87601391d28b930a19e',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fcontrol3_5freg_234',['DATAIF_ASP_CONTROL3_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#gaf79d69f57ca452b90c7645424a6a6817',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fdata_5fcontrol1_5freg_235',['DATAIF_ASP_DATA_CONTROL1_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#gad5397deac0c4b92a4c1fd75716595761',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fdata_5fcontrol5_5freg_236',['DATAIF_ASP_DATA_CONTROL5_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#ga0d3f859268e1e0e166294daa7e645548',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fenables1_5freg_237',['DATAIF_ASP_ENABLES1_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#ga2ba348d1c599504cf7f375f367060773',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fframe_5fcontrol1_5freg_238',['DATAIF_ASP_FRAME_CONTROL1_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#ga13238096ad1b0ab56635b52de656337b',1,'cs35l41_spec.h']]],
  ['dataif_5fasp_5fframe_5fcontrol5_5freg_239',['DATAIF_ASP_FRAME_CONTROL5_REG',['../group___s_e_c_t_i_o_n__7__10___d_a_t_a_i_f.html#ga4b66bfa908de550effe58c598f7b53f7',1,'cs35l41_spec.h']]],
  ['devid_240',['devid',['../structcs35l41__t.html#a0388edec69af15368578960ab50d0642',1,'cs35l41_t']]],
  ['disable_5firq_241',['disable_irq',['../structbsp__driver__if__t.html#ab7dde8dfca33bc4f538539e185c7c840',1,'bsp_driver_if_t']]],
  ['dout_5fhiz_5fctrl_242',['dout_hiz_ctrl',['../structcs35l41__audio__hw__config__t.html#a6240e6c36bc6eb25c6ad2432747b80a8',1,'cs35l41_audio_hw_config_t']]],
  ['dsp_5frx1_5fsrc_243',['dsp_rx1_src',['../structcs35l41__routing__config__t.html#adaf017cfa4c6577ad0208ac81b1d7f85',1,'cs35l41_routing_config_t']]],
  ['dsp_5frx2_5fsrc_244',['dsp_rx2_src',['../structcs35l41__routing__config__t.html#afb9ddc54bc6b483d816835cbc2c36c19',1,'cs35l41_routing_config_t']]]
];
