var searchData=
[
  ['notification_5fcb_492',['notification_cb',['../structcs35l41__bsp__config__t.html#a6de32f205ae46c1ec1a8aaf5a331157b',1,'cs35l41_bsp_config_t']]],
  ['notification_5fcb_5farg_493',['notification_cb_arg',['../structcs35l41__bsp__config__t.html#aa5b5137e0d56f4ab77c799ae6910dcc7',1,'cs35l41_bsp_config_t']]],
  ['num_5felements_494',['num_elements',['../structcs35l41__otp__map__t.html#a72880309bbc485113108f5613d06e978',1,'cs35l41_otp_map_t']]]
];
