var searchData=
[
  ['bclk_5finv_502',['bclk_inv',['../structcs35l41__audio__hw__config__t.html#af75ac9bfd3a9fcc5fba1f5e2abf9528c',1,'cs35l41_audio_hw_config_t']]],
  ['bit_5foffset_503',['bit_offset',['../structcs35l41__otp__map__t.html#a7995c39d3359671f22bb1f4216e08306',1,'cs35l41_otp_map_t']]],
  ['boost_5fcapacitor_5fvalue_5fuf_504',['boost_capacitor_value_uf',['../structcs35l41__amp__config__t.html#a60443e1c11c54fa872ee76e026b48cd9',1,'cs35l41_amp_config_t']]],
  ['boost_5finductor_5fvalue_5fnh_505',['boost_inductor_value_nh',['../structcs35l41__amp__config__t.html#aafa1337d028c3e4757a25132d6af4622',1,'cs35l41_amp_config_t']]],
  ['boost_5fipeak_5fma_506',['boost_ipeak_ma',['../structcs35l41__amp__config__t.html#aa90f94c15eae4a0066cacce25e6197f2',1,'cs35l41_amp_config_t']]],
  ['bsp_5fconfig_507',['bsp_config',['../structcs35l41__config__t.html#a5ab820bb6a4f0f8d416b0e06e06ef250',1,'cs35l41_config_t']]],
  ['bsp_5fdev_5fid_508',['bsp_dev_id',['../structcs35l41__bsp__config__t.html#a5efc0445a421d93cb6d137ef92682442',1,'cs35l41_bsp_config_t']]],
  ['bsp_5fdriver_5fif_5fg_509',['bsp_driver_if_g',['../bsp__driver__if_8h.html#af9eab00f5b6129ff32f07ba0697df57d',1,'bsp_driver_if.h']]],
  ['bsp_5fint_5fgpio_5fid_510',['bsp_int_gpio_id',['../structcs35l41__bsp__config__t.html#a501bd7846a9024571f8942e18b34c30b',1,'cs35l41_bsp_config_t']]],
  ['bsp_5freset_5fgpio_5fid_511',['bsp_reset_gpio_id',['../structcs35l41__bsp__config__t.html#a480555b8baaafef0cfd1ae7931317408',1,'cs35l41_bsp_config_t']]],
  ['bst_5fctl_512',['bst_ctl',['../structcs35l41__amp__config__t.html#a7c6737f43c40c7e953cdeabe3b93fce3',1,'cs35l41_amp_config_t']]],
  ['bst_5fctl_5flim_5fen_513',['bst_ctl_lim_en',['../structcs35l41__amp__config__t.html#a75c97ae87747d8a5b1fb409a8c2a5981',1,'cs35l41_amp_config_t']]],
  ['bst_5fctl_5fsel_514',['bst_ctl_sel',['../structcs35l41__amp__config__t.html#a452b319dfc51e04b994407cbead8abec',1,'cs35l41_amp_config_t']]],
  ['bus_5ftype_515',['bus_type',['../structcs35l41__bsp__config__t.html#a268c036cb877a26308af9e0187ee0869',1,'cs35l41_bsp_config_t']]]
];
