var searchData=
[
  ['notification_5fcb',['notification_cb',['../structcs40l25__bsp__config__t.html#a6981ab12d2aedc50e7f30cda2d19d707',1,'cs40l25_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs40l25__bsp__config__t.html#a8f087271c59e9e5cc70c9410869f5e42',1,'cs40l25_bsp_config_t']]]
];
