var searchData=
[
  ['noise_5fgate_5fmixer_5fngate_5fch1_5fcfg_5freg',['NOISE_GATE_MIXER_NGATE_CH1_CFG_REG',['../group__SECTION__7__21__NOISE__GATE.html#gaca035e6f07aede96068a6cd588338c4d',1,'cs35l41_spec.h']]],
  ['noise_5fgate_5fmixer_5fngate_5fch2_5fcfg_5freg',['NOISE_GATE_MIXER_NGATE_CH2_CFG_REG',['../group__SECTION__7__21__NOISE__GATE.html#gacb3c3083fce4718e4cf35f47a59ad9ab',1,'cs35l41_spec.h']]],
  ['notification_5fcb',['notification_cb',['../structcs35l41__bsp__config__t.html#a6de32f205ae46c1ec1a8aaf5a331157b',1,'cs35l41_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs35l41__bsp__config__t.html#aa5b5137e0d56f4ab77c799ae6910dcc7',1,'cs35l41_bsp_config_t']]],
  ['num_5felements',['num_elements',['../structcs35l41__otp__map__t.html#a72880309bbc485113108f5613d06e978',1,'cs35l41_otp_map_t']]]
];
