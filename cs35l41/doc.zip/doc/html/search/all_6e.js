var searchData=
[
  ['ng_5fdelay',['ng_delay',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga00eda1c26e0dbc2062ce7e18de6f7554',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fenable',['ng_enable',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga37671285e5cc316267413f2136d58041',1,'cs40l25_audio_hw_config_t']]],
  ['ng_5fthld',['ng_thld',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga5c7fcca5dc7a65445d40b331047e5e49',1,'cs40l25_audio_hw_config_t']]],
  ['notification_5fcb',['notification_cb',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga5a60d7aa7688c330b39cb3cd8ea21d50',1,'cs40l25_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#gaa5868ae1db251f8092120dc07ede2106',1,'cs40l25_config_t']]]
];
