var searchData=
[
  ['set_5fgpio_501',['set_gpio',['../structbsp__driver__if__t.html#a70afcf1a76958fba2a8f85dbd220dd83',1,'bsp_driver_if_t']]],
  ['set_5fsupply_502',['set_supply',['../structbsp__driver__if__t.html#aa399aa589bb0f95732b1710fc97ca3f6',1,'bsp_driver_if_t']]],
  ['set_5ftimer_503',['set_timer',['../structbsp__driver__if__t.html#a1586994324a4a49f60a116dc6f6d59de',1,'bsp_driver_if_t']]],
  ['shift_504',['shift',['../structcs35l41__otp__packed__entry__t.html#acd36001363941b78186c99b71c8e04d8',1,'cs35l41_otp_packed_entry_t::shift()'],['../structcs35l41__field__accessor__t.html#a24ddeb5bd9292846d40f91e598c75f95',1,'cs35l41_field_accessor_t::shift()']]],
  ['size_505',['size',['../structcs35l41__otp__packed__entry__t.html#a9af1d2d784c543a8dbe9c3b67107e995',1,'cs35l41_otp_packed_entry_t::size()'],['../structcs35l41__field__accessor__t.html#a4a284dbaf3a408398802a0a93e59fbbc',1,'cs35l41_field_accessor_t::size()']]],
  ['spi_5fread_506',['spi_read',['../structbsp__driver__if__t.html#affa3c679ade482e0bcd09e44e9dc16a9',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed_507',['spi_restore_speed',['../structbsp__driver__if__t.html#abfcc7cd8c48dcde1b896bd4f7dfed70d',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed_508',['spi_throttle_speed',['../structbsp__driver__if__t.html#ab79f6761c94f11a643a2e8d22e486128',1,'bsp_driver_if_t']]],
  ['spi_5fwrite_509',['spi_write',['../structbsp__driver__if__t.html#a5ad22c13d70045408dfcde74b8d7634c',1,'bsp_driver_if_t']]],
  ['state_510',['state',['../structcs35l41__t.html#aca3de20e44ac0ee9d1f0932a1114c655',1,'cs35l41_t']]],
  ['syscfg_5fregs_511',['syscfg_regs',['../structcs35l41__config__t.html#a15eeb03b7f15eb5108e8cf97f72511d3',1,'cs35l41_config_t']]],
  ['syscfg_5fregs_5ftotal_512',['syscfg_regs_total',['../structcs35l41__config__t.html#a6481d73d919a3327fae95b82deb991c9',1,'cs35l41_config_t']]]
];
