var searchData=
[
  ['otp_5fbit_5fcount_766',['otp_bit_count',['../structcs35l41__t.html#ad2700637f633e2c4119dadcf5c8c91b6',1,'cs35l41_t']]],
  ['otp_5fmap_767',['otp_map',['../structcs35l41__t.html#a648cd32a2ec9ee74387496eaf7de3305',1,'cs35l41_t']]],
  ['otp_5fmap_5f1_768',['otp_map_1',['../cs35l41_8c.html#a76b5e16399942433e00eb52bc96e21fb',1,'cs35l41.c']]]
];
