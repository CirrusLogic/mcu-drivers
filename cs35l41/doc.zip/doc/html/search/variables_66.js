var searchData=
[
  ['fa_5flist',['fa_list',['../cs35l41_8c.html#a9f5c2873a9ba897f18c85330b7296c33',1,'cs35l41.c']]],
  ['fsync_5finv',['fsync_inv',['../structcs35l41__audio__hw__config__t.html#a8ad5e74337e7243b60115f5b5baa0186',1,'cs35l41_audio_hw_config_t']]],
  ['fw_5finfo',['fw_info',['../structcs35l41__t.html#a763593dfd50252dc8113f803b7dfc192',1,'cs35l41_t']]]
];
