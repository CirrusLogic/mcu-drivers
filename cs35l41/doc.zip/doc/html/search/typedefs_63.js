var searchData=
[
  ['cs40l25_5fnotification_5fcallback_5ft',['cs40l25_notification_callback_t',['../cs40l25_8h.html#a6c29a42cf63332c3ecdc5b95773a7e0f',1,'cs40l25.h']]]
];
