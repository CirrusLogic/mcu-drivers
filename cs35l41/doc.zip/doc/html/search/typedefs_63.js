var searchData=
[
  ['cs35l41_5fnotification_5fcallback_5ft',['cs35l41_notification_callback_t',['../cs35l41_8h.html#a085ae3e620390963c8cd3451155c87f2',1,'cs35l41.h']]]
];
