var searchData=
[
  ['wkfet_5famp_5fdelay',['wkfet_amp_delay',['../structcs35l41__amp__config__t.html#a29900d8e62dd8b55d16b2ee787b5e2e5',1,'cs35l41_amp_config_t']]],
  ['wkfet_5famp_5fthld',['wkfet_amp_thld',['../structcs35l41__amp__config__t.html#abc73ad97278295c0bbd226e1656c1821',1,'cs35l41_amp_config_t']]]
];
