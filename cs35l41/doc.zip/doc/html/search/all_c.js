var searchData=
[
  ['r_305',['r',['../structcs35l41__calibration__t.html#ad7203729bdb96c122b52958348c30773',1,'cs35l41_calibration_t']]],
  ['reg_306',['reg',['../structcs35l41__otp__packed__entry__t.html#a0c2813f1f1d9b517fad2565c6a26c063',1,'cs35l41_otp_packed_entry_t']]],
  ['register_5fgpio_5fcb_307',['register_gpio_cb',['../structbsp__driver__if__t.html#a11e60a843ba9d408cdb6c781af0b9705',1,'bsp_driver_if_t']]],
  ['revid_308',['revid',['../structcs35l41__t.html#a097b777543982e6e31d242406499bd36',1,'cs35l41_t']]]
];
