var searchData=
[
  ['otp_5fbit_5fcount_407',['otp_bit_count',['../structcs35l41__t.html#ad2700637f633e2c4119dadcf5c8c91b6',1,'cs35l41_t']]],
  ['otp_5fctrl_5fotp_5fctrl8_5fotp_5fboot_5fdone_5fsts_5fbitmask_408',['OTP_CTRL_OTP_CTRL8_OTP_BOOT_DONE_STS_BITMASK',['../group___s_e_c_t_i_o_n__7__4___o_t_p___c_t_r_l.html#ga76f23dbcfeaadb3f97d313655344aa6c',1,'cs35l41_spec.h']]],
  ['otp_5fmap_409',['otp_map',['../structcs35l41__t.html#a648cd32a2ec9ee74387496eaf7de3305',1,'cs35l41_t']]],
  ['otp_5fmap_5f1_410',['otp_map_1',['../cs35l41_8c.html#a76b5e16399942433e00eb52bc96e21fb',1,'cs35l41.c']]]
];
