var searchData=
[
  ['get_5fdsp_5fstatus_5fsm',['get_dsp_status_sm',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga26c99f20ea05f3f87c77e137cfc0b22c',1,'cs40l25_private_functions_t']]],
  ['get_5ferrata',['get_errata',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#gae6c5a54ffa26cf99f9f2a44f673ed438',1,'cs40l25_private_functions_t']]],
  ['global_5ffs',['global_fs',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga584bca5724799be18ff9546b618499cc',1,'cs40l25_clock_config_t']]],
  ['gp1_5fctrl',['gp1_ctrl',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#gadff32aeb3f7e8007ef5faa7ea18feebe',1,'cs40l25_clock_config_t']]],
  ['gp2_5fctrl',['gp2_ctrl',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga99f19d2d38bb16ffacf4c66e2779d9d1',1,'cs40l25_clock_config_t']]],
  ['gpio1',['gpio1',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga8ad226e179bb1e53ecfb4d714049f789',1,'cs40l25_event_control_t::gpio1()'],['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga6c4048540621bab2783153cf95362525',1,'cs40l25_event_control_t::@0::@2::gpio1()']]],
  ['gpio2',['gpio2',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga7e9462e2dc8c9a13245d4948dd8fd718',1,'cs40l25_event_control_t::gpio2()'],['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga0e0dde4708b7eeaa0d8bbe0fa2bf57f5',1,'cs40l25_event_control_t::@0::@2::gpio2()']]],
  ['gpio3',['gpio3',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga9fa26ec7950ee2906bbd08bb3eba9074',1,'cs40l25_event_control_t::gpio3()'],['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#gaa09bd1be6cfedf3486769e11e2868fc4',1,'cs40l25_event_control_t::@0::@2::gpio3()']]],
  ['gpio4',['gpio4',['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#gade5dd68be033c43969e93784ff978dda',1,'cs40l25_event_control_t::gpio4()'],['../group__CS40L25__DYNAMIC__F0__SM__STATE__.html#ga47e9ec409af2ece6ad8166c49a5e1832',1,'cs40l25_event_control_t::@0::@2::gpio4()']]]
];
