var searchData=
[
  ['cs35l41_5fnotification_5fcallback_5ft_515',['cs35l41_notification_callback_t',['../cs35l41_8h.html#a342b87a54a7c071cdd662fe43506d6a8',1,'cs35l41.h']]]
];
